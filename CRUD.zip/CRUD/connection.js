const mysql = require("mysql");
var connection = mysql.createConnection({
    port:3307,
    host:"localhost",
    user:"root",
    password:"123456",
    database:"crud"
})

connection.connect((err)=>{
    if(!err){
        console.log("Connected")
    }
    else{
        console.log(err);
    }
    module.exports = connection;
})