CREATE TABLE PRODUCT(
    id int NOT NULL AUTO_INCREMENT,
    product_name varchar(255) NOT NULL,
    product_category varchar(255),
    image_url varchar(255),
    product_description varchar(255),
    PRIMARY KEY(id)
);